﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PurchaseOrder
{
    public class MainProgram
    {
        public static void Main(string[] args)
        {
            foreach (var cust in GetCustomers())
            {
                Console.WriteLine($"{cust.FirstName} {cust.LastName}");
                for (int i = 0; i < cust.Orders.Length; i++)
                {
                    Console.Write("{0} - {1:C} - {2}{3} ", cust.Orders[i].Description, cust.Orders[i].Price, cust.Orders[i].Quantity, i == cust.Orders.Length-1 ? "" : ",");
                }
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
            }
            Console.ReadLine();
        }

        private static Customer[] GetCustomers()
        {
            return new Customer[] {
            new Customer {FirstName = "John", LastName = "Hinz", Orders = new Order[] {new Order { Description = "Sugar", Quantity = 5, Price = 5.67M }, new Order { Description = "Milk", Price = 3.80M, Quantity = 3}, new Order { Description = "Soap", Price = 5.50M, Quantity = 9 } } },
            new Customer {FirstName = "Kazeem", LastName = "Odukale", Orders = new Order[] {new Order { Description = "Bread", Quantity = 2, Price = 1.00M}, new Order { Description = "Cream", Quantity = 4, Price = 12.60M }, new Order { Description = "Patty", Price = 1.70M, Quantity = 2} } },
            new Customer {FirstName = "Joe", LastName = "Smith", Orders = new Order[] {new Order {Description = "Butter", Quantity = 6, Price = 6.10M }, new Order { Description = "Soap", Quantity = 12, Price = 1.50M }, new Order { Description = "Iron", Price = 35.13M, Quantity = 1} } } };
        }
    }
}
