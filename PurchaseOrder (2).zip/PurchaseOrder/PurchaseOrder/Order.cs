﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PurchaseOrder
{
    class Order
    {
        private string description;
        private decimal price;
        private int quantity;

        public Order()
        {
            description = string.Empty;
            price = 0.0M;
            quantity = 0;
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (value >= 0)
                    quantity = value;
            }
        }

        public string Description
        {
            get { return description; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                    description = value;
            }
        }

        public Decimal Price
        {
            get { return price; }
            set { if (value >= 0)
                    price = value;
            }
        }
    }
}
